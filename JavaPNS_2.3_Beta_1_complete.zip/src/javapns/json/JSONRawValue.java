package javapns.json;

public interface JSONRawValue {

	@Override
	public String toString();
	
}
